# CARLOS — MÁLAGA 2027 · raport wdrożenia patcha

Podstawa: dokument „CARLOS — MÁLAGA 2027 · zestaw poprawek”.

## Wdrożone

### Prawda o danych
- jawna mapa `FIELD_ALIASES`
- exact match bez fuzzy `includes`
- parser `pl-PL`: przecinek, NBSP, jednostki
- czas `7:45` nie jest interpretowany jako `745`
- trzy stany pierścienia: wartość / brak / błąd
- walidacja required fields i zakresów
- kontrola dat D.M.Y / ISO, odrzucanie overflow
- sortowanie bezdatowych wpisów na koniec
- „Najbliższe sesje” tylko dla przyszłych poprawnych dat
- skeleton przed pierwszym fetchem

### Sieć i offline
- `AbortController` + timeout 8 s
- `Promise.allSettled` dla częściowych awarii
- debounce 60 s dla `visibilitychange`
- obsługa iOS `pageshow` / bfcache
- last-known-good w `localStorage`
- osobne stany: live / partial / stale / offline

### iOS PWA
- `viewport-fit=cover`
- `safe-area-inset-top` i `safe-area-inset-bottom`
- nawigacja mobilna do 880 px
- Refresh minimum 44×44 px
- PNG: 180/192/512
- manifest standalone

### Czytelność / performance
- kontrast `--muted: #8f98aa`
- brak ukrywania alertów na mobile
- kompaktowy hero na <=640 px
- `100dvh`
- systemowy font stack, bez nieładowanego Inter
- blur tylko topbar i mobile-nav
- brak fałszywego 2% słupka dla zerowej strefy

### Service worker
- cache v2
- `Promise.allSettled` zamiast `addAll`
- `skipWaiting()` w `waitUntil`
- `clients.claim()` po activate
- timeout na navigation
- cache shell tylko dla poprawnej odpowiedzi
- Google Sheets nigdy cache-first

### Testy
- wydzielony `src/parse.js`
- `src/parse.test.js` dla Vitest
- lokalna regresja parsera wykonana bez zależności npm: 18/18 OK
- `main.jsx` przeszedł parser JSX TypeScript bez błędów składni
- JSON manifest/package poprawny

## Nie wykonano w tym środowisku

`npm install`, `npm test` i `npm run build` nie mogły zostać uruchomione, ponieważ środowisko wykonawcze nie ma dostępu do registry npm i nie ma pakietów w cache. Vercel po commicie wykona pełny install/build w swoim środowisku.

## Świadomie poza tym patchem

Zgodnie z kolejnością dokumentu: prywatny Google Sheet + Vercel API z sesją HttpOnly, kalkulator Málaga i ewentualna zmiana modelu stref HR są kolejnymi etapami.

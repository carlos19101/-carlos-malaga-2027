# GITHUB APPLY BUNDLE — CARLOS MÁLAGA 2027
Repo: `carlos19101/-carlos-malaga-2027`, branch: `main`.
Instrukcja dla agenta GitHub: zastąp/utwórz poniższe pliki dokładnie pod wskazanymi ścieżkami. Pliki PNG `public/icon-180.png`, `public/icon-192.png`, `public/icon-512.png` znajdują się osobno w ZIP-ie i muszą zostać dodane jako binarne. Po zapisie uruchom/zweryfikuj build, jeśli narzędzia na to pozwalają.

## `package.json`

```json
{
  "name": "carlos-malaga-2027",
  "private": true,
  "version": "2.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "test": "vitest run"
  },
  "dependencies": {
    "@vitejs/plugin-react": "latest",
    "vite": "latest",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "vitest": "latest"
  }
}

```

## `vite.config.js`

```javascript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { host: true },
});

```

## `index.html`

```html
<!doctype html>
<html lang="pl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
    <meta name="theme-color" content="#07090d" />
    <meta name="color-scheme" content="dark" />
    <meta name="description" content="CARLOS — MÁLAGA 2027: trening, strefy, log i plan w jednej aplikacji PWA." />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="CARLOS" />
    <link rel="manifest" href="./manifest.webmanifest" />
    <link rel="icon" href="./icon.svg" type="image/svg+xml" />
    <link rel="apple-touch-icon" sizes="180x180" href="./icon-180.png" />
    <title>CARLOS — MÁLAGA 2027</title>
    <style>
      html, body { margin: 0; background: #07090d; }
      #root:empty::before {
        content: '';
        display: block;
        min-height: 100dvh;
        background:
          radial-gradient(circle at 18% -4%, rgba(255,123,42,.11), transparent 20rem),
          #07090d;
      }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>

```

## `src/parse.js`

```javascript
export function normalize(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');
}

export function parseCSV(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;

  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else if (ch === '"') {
        quoted = false;
      } else {
        cell += ch;
      }
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ',') {
      row.push(cell);
      cell = '';
    } else if (ch === '\n') {
      row.push(cell.replace(/\r$/, ''));
      rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += ch;
    }
  }

  if (cell.length || row.length) {
    row.push(cell.replace(/\r$/, ''));
    rows.push(row);
  }

  const nonEmpty = rows.filter((r) => r.some((v) => String(v).trim() !== ''));
  if (!nonEmpty.length) return [];
  const headers = nonEmpty[0].map((h, i) => String(h).trim() || `column_${i + 1}`);
  return nonEmpty.slice(1).map((values) => {
    const out = {};
    headers.forEach((header, i) => { out[header] = values[i] ?? ''; });
    return out;
  });
}

export const CLOCK_RE = /^\d{1,3}:[0-5]\d(:[0-5]\d)?$/;

export function parseClock(value) {
  const raw = String(value ?? '').trim();
  if (!CLOCK_RE.test(raw)) return null;
  const p = raw.split(':').map(Number);
  return p.length === 2 ? p[0] * 60 + p[1] : p[0] * 60 + p[1] + p[2] / 60;
}

export function parseNumber(value) {
  if (value === null || value === undefined) return null;
  const raw = String(value).trim();
  if (!raw || raw.includes(':') || /^(?:—|-|#N\/A|N\/A|null|undefined)$/i.test(raw)) return null;

  const cleaned = raw
    .replace(/\s/g, '')
    .replace(',', '.')
    .replace(/[^0-9.+-]/g, '');

  if (!cleaned || !/\d/.test(cleaned)) return null;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

export function parseMetric(value) {
  return parseNumber(value) ?? parseClock(value);
}

export function parseDate(value) {
  if (!value) return null;
  const raw = String(value).trim();

  if (/^\d{4}-\d{2}-\d{2}/.test(raw)) {
    const d = new Date(raw);
    return Number.isNaN(d.getTime()) ? null : d;
  }

  const m = raw.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})(?:[\sT]+(\d{1,2}):(\d{2}))?/);
  if (!m) return null;

  let [, day, month, year, hh = '0', mm = '0'] = m;
  day = Number(day);
  month = Number(month);
  year = Number(year);
  const hour = Number(hh);
  const minute = Number(mm);
  if (year < 100) year += 2000;

  if (month < 1 || month > 12 || day < 1 || day > 31 || hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  const d = new Date(year, month - 1, day, hour, minute);
  if (d.getFullYear() !== year || d.getMonth() !== month - 1 || d.getDate() !== day) return null;
  return d;
}

```

## `src/parse.test.js`

```javascript
import { describe, it, expect } from 'vitest';
import { parseNumber, parseClock, parseDate, parseCSV } from './parse';

describe('parseNumber — locale pl-PL', () => {
  it('przecinek dziesiętny', () => expect(parseNumber('11,17')).toBe(11.17));
  it('zero po przecinku', () => expect(parseNumber('89,0')).toBe(89));
  it('NBSP jako tysiące', () => expect(parseNumber('1\u00A0234,5')).toBe(1234.5));
  it('spacja jako tysiące', () => expect(parseNumber('1 234,5')).toBe(1234.5));
  it('jednostka w komórce', () => expect(parseNumber('48 bpm')).toBe(48));
  it('pusta komórka to null, NIE zero', () => expect(parseNumber('')).toBeNull());
  it('myślnik', () => expect(parseNumber('—')).toBeNull());
  it('błąd Sheets', () => expect(parseNumber('#N/A')).toBeNull());
  it('czas NIE jest liczbą', () => expect(parseNumber('7:45')).toBeNull());
  it('czas długi', () => expect(parseNumber('1:25:19')).toBeNull());
});

describe('parseClock', () => {
  it('godziny:minuty', () => expect(parseClock('7:45')).toBe(465));
  it('odrzuca liczbę', () => expect(parseClock('745')).toBeNull());
});

describe('parseDate', () => {
  it('ISO', () => expect(parseDate('2026-08-22').getMonth()).toBe(7));
  it('pl', () => expect(parseDate('22.08.2026').getDate()).toBe(22));
  it('z godziną', () => expect(parseDate('22.08.2026 14:30').getHours()).toBe(14));
  it('odrzuca miesiąc > 12', () => expect(parseDate('8-22-2026')).toBeNull());
  it('odrzuca 32 dzień', () => expect(parseDate('32.01.2026')).toBeNull());
  it('śmieci', () => expect(parseDate('brak')).toBeNull());
});

describe('parseCSV', () => {
  it('obsługuje przecinek wewnątrz cudzysłowu', () => {
    expect(parseCSV('A,B\n"11,17",x\n')[0]).toEqual({ A: '11,17', B: 'x' });
  });
});

```

## `src/main.jsx`

```jsx
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { normalize, parseCSV, parseDate, parseMetric, parseNumber } from './parse';
import './styles.css';

const SHEET_ID = '1FoExswYMSy5Ou2HwyzPd3bWgnplWgfPGCd5scC0lCXM';
const SHEETS = {
  feed: 'APP_FEED',
  log: 'Training Log',
  plan: 'Plan',
};

const SNAPSHOT_KEY = 'carlos:snapshot:v2';
const FETCH_TIMEOUT = 8000;
const MIN_REFRESH_MS = 60000;
const STALE_AFTER_MS = 36 * 60 * 60 * 1000;

const TABS = [
  { id: 'dashboard', label: 'Dashboard', icon: '◉' },
  { id: 'zones', label: 'Strefy', icon: '◒' },
  { id: 'log', label: 'Log', icon: '≡' },
  { id: 'plan', label: 'Plan', icon: '◇' },
];

const FIELD_ALIASES = {
  date: ['date', 'data', 'day', 'dzien', 'timestamp', 'datetime', 'czas'],
  recovery: ['recovery', 'recovery score', 'regeneracja', 'readiness', 'gotowosc'],
  strain: ['strain', 'day strain', 'obciazenie dnia'],
  srpe: ['srpe', 's rpe', 'srpe today', 'obciazenie'],
  sleep: ['sleep', 'sleep score', 'sleep performance', 'sen'],
  hrv: ['hrv', 'heart rate variability', 'zmiennosc'],
  rhr: ['rhr', 'resting hr', 'resting heart rate', 'tetno spoczynkowe'],
  weight: ['weight', 'waga', 'body weight', 'masa'],
  steps: ['steps', 'kroki'],
  session: ['session', 'workout', 'training', 'trening', 'nazwa', 'title', 'zadanie'],
  target: ['target', 'cel', 'focus', 'intensity', 'intensywnosc'],
  notes: ['notes', 'note', 'uwagi', 'opis', 'description'],
  duration: ['duration', 'czas trwania', 'time', 'minutes', 'min'],
  calories: ['calories', 'kcal', 'kalorie'],
  z1: ['z1', 'zone 1', 'strefa 1', 'czas z1'],
  z2: ['z2', 'zone 2', 'strefa 2', 'czas z2'],
  z3: ['z3', 'zone 3', 'strefa 3', 'czas z3'],
  z4: ['z4', 'zone 4', 'strefa 4', 'czas z4'],
  z5: ['z5', 'zone 5', 'strefa 5', 'czas z5'],
  __label__: ['metric', 'metryka', 'name', 'nazwa', 'label', 'parametr', 'kpi', 'key'],
  __value__: ['value', 'wartosc', 'current', 'wynik', 'result', 'score'],
};

const REQUIRED_FEED = ['recovery', 'hrv', 'rhr', 'weight'];
const RANGES = {
  hrv: [10, 200],
  rhr: [30, 110],
  weight: [60, 130],
  recovery: [0, 100],
  sleep: [0, 100],
};
const MAX_DELTA = { weight: 1.5, rhr: 15, hrv: 40 };

const ZONE_META = [
  { id: 1, name: 'Recovery', note: 'bardzo lekko', color: '#58c5e8' },
  { id: 2, name: 'Aerobic', note: 'baza tlenowa', color: '#64d8a2' },
  { id: 3, name: 'Tempo', note: 'kontrolowana praca', color: '#f3c846' },
  { id: 4, name: 'Threshold', note: 'próg', color: '#f07822' },
  { id: 5, name: 'Peak', note: 'wysoka intensywność', color: '#ef4867' },
];

function sheetUrl(sheetName) {
  return `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}&_t=${Date.now()}`;
}

async function fetchSheet(sheetName, signal) {
  const response = await fetch(sheetUrl(sheetName), {
    cache: 'no-store',
    signal,
    headers: { Accept: 'text/csv,text/plain;q=0.9,*/*;q=0.8' },
  });
  if (!response.ok) throw new Error(`${sheetName}: HTTP ${response.status}`);
  const text = await response.text();
  if (!text.trim()) return [];
  if (/^\s*</.test(text) && /<html/i.test(text)) {
    throw new Error(`${sheetName}: brak dostępu do arkusza (HTML zamiast CSV)`);
  }
  return parseCSV(text);
}

function findKey(row, candidates) {
  if (!row) return null;
  const wanted = new Set(candidates.map(normalize));
  return Object.keys(row).find((key) => wanted.has(normalize(key))) || null;
}

function resolveField(row, field) {
  const aliases = FIELD_ALIASES[field];
  if (!aliases) return { status: 'error', reason: `nieznane pole: ${field}` };
  const key = findKey(row, aliases);
  if (!key) return { status: 'missing', column: null, value: '' };
  const raw = String(row[key] ?? '').trim();
  return { status: raw === '' ? 'empty' : 'ok', column: key, value: raw };
}

function getValue(row, field, fallback = '') {
  const r = resolveField(row, field);
  return r.status === 'ok' ? r.value : fallback;
}

function getFeedValue(rows, latest, field, fallback = '') {
  const direct = resolveField(latest, field);
  if (direct.status === 'ok') return direct.value;

  const wanted = new Set((FIELD_ALIASES[field] || []).map(normalize));
  for (const row of rows) {
    const label = normalize(getValue(row, '__label__', ''));
    if (label && wanted.has(label)) {
      const v = getValue(row, '__value__', '');
      if (v !== '') return v;
    }
  }
  return fallback;
}

function rowDate(row) {
  return parseDate(getValue(row, 'date', ''));
}

function sortByDate(rows, direction = 'desc') {
  return rows
    .map((row, i) => ({ row, i, t: rowDate(row)?.getTime() ?? null }))
    .sort((a, b) => {
      if (a.t === null && b.t === null) return a.i - b.i;
      if (a.t === null) return 1;
      if (b.t === null) return -1;
      return direction === 'asc' ? a.t - b.t : b.t - a.t;
    })
    .map((x) => x.row);
}

function latestRow(rows) {
  if (!rows?.length) return {};
  return sortByDate(rows, 'desc')[0] || {};
}

function validateFeed(rows, latest, previous) {
  const missing = [];
  const suspicious = [];

  for (const field of REQUIRED_FEED) {
    if (resolveField(latest, field).status === 'missing' && getFeedValue(rows, latest, field, '') === '') {
      missing.push(field);
    }
  }

  for (const [field, [lo, hi]] of Object.entries(RANGES)) {
    const n = parseMetric(getFeedValue(rows, latest, field, ''));
    if (n === null) continue;
    if (n < lo || n > hi) suspicious.push(`${field}=${n} poza zakresem ${lo}–${hi}`);
    const prev = previous ? parseMetric(getFeedValue(rows, previous, field, '')) : null;
    const cap = MAX_DELTA[field];
    if (cap && prev !== null && Math.abs(n - prev) > cap) {
      suspicious.push(`${field}: skok o ${Math.abs(n - prev).toFixed(1)} (limit ${cap})`);
    }
  }

  return { missing, suspicious, ok: missing.length === 0 };
}

function formatUpdated(date) {
  if (!date || Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('pl-PL', {
    day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit',
  }).format(date);
}

function formatDate(value) {
  const d = parseDate(value);
  if (!d) return value || '—';
  return new Intl.DateTimeFormat('pl-PL', { day: 'numeric', month: 'short' }).format(d);
}

function ringProgress(value, max) {
  const n = parseMetric(value);
  if (n === null) return null;
  return Math.max(0, Math.min(100, (n / max) * 100));
}

function displayValue(value, suffix = '') {
  if (value === null || value === undefined || String(value).trim() === '') return '—';
  const raw = String(value).trim();
  if (!suffix) return raw;
  if (raw.endsWith(suffix)) return raw;
  return `${raw}${suffix}`;
}

function MetricRing({ label, value, max = 100, suffix = '%', note, issue }) {
  const progress = ringProgress(value, max);
  const state = issue ? 'error' : progress === null ? 'empty' : 'ok';
  const shown = state === 'ok' ? displayValue(value, suffix) : state === 'error' ? '!' : '—';
  return (
    <article className={`ring-card ring-${state}`}>
      <div className="metric-ring" style={{ '--progress': `${(progress ?? 0) * 3.6}deg` }}>
        <div className="metric-ring-inner">
          <strong>{shown}</strong>
          <span>{label}</span>
        </div>
      </div>
      {state === 'ok'
        ? <p>{note}</p>
        : <p className="ring-note-issue">{state === 'error' ? issue : 'brak danych w arkuszu'}</p>}
    </article>
  );
}

function StatCard({ label, value, unit, note }) {
  const empty = value === null || value === undefined || String(value).trim() === '';
  return (
    <article className="stat-card">
      <span>{label}</span>
      <strong>{empty ? '—' : value}{!empty && unit ? <small> {unit}</small> : null}</strong>
      <small>{note}</small>
    </article>
  );
}

function SkeletonRings() {
  return <div className="skeleton-rings" aria-hidden="true"><i /><i /><i /></div>;
}

function EmptyState({ title, children }) {
  return (
    <section className="empty-state">
      <span className="empty-mark">—</span>
      <div><strong>{title}</strong><p>{children}</p></div>
    </section>
  );
}

function Hero({ eyebrow, title, children, orbit = true }) {
  return (
    <section className="hero-panel">
      <div className="hero-copy">
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        {children ? <p>{children}</p> : null}
      </div>
      {orbit ? <div className="hero-orbit" aria-hidden="true"><b>C</b></div> : null}
    </section>
  );
}

function Dashboard({ feed, plan, loading }) {
  const sortedFeed = useMemo(() => sortByDate(feed, 'desc'), [feed]);
  const latest = sortedFeed[0] || {};
  const previous = sortedFeed[1] || null;
  const validation = useMemo(() => validateFeed(feed, latest, previous), [feed, latest, previous]);

  const values = {
    recovery: getFeedValue(feed, latest, 'recovery', ''),
    strain: getFeedValue(feed, latest, 'strain', ''),
    srpe: getFeedValue(feed, latest, 'srpe', ''),
    sleep: getFeedValue(feed, latest, 'sleep', ''),
    hrv: getFeedValue(feed, latest, 'hrv', ''),
    rhr: getFeedValue(feed, latest, 'rhr', ''),
    weight: getFeedValue(feed, latest, 'weight', ''),
    steps: getFeedValue(feed, latest, 'steps', ''),
  };

  const issueFor = (field) => {
    if (validation.missing.includes(field)) return `brak wymaganej kolumny: ${field}`;
    return validation.suspicious.find((x) => x.startsWith(`${field}=`) || x.startsWith(`${field}:`)) || '';
  };

  const upcoming = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return sortByDate(plan, 'asc')
      .filter((row) => { const d = rowDate(row); return d && d >= today; })
      .slice(0, 3);
  }, [plan]);

  return (
    <>
      <Hero eyebrow="MÁLAGA 2027" title="Forma, która ma kierunek.">
        Jeden widok na regenerację, obciążenie, sen i plan.
      </Hero>

      <section className="section-block">
        <div className="section-heading"><div><span className="eyebrow">DZISIAJ</span><h2>Sygnały organizmu</h2></div></div>

        {!validation.ok || validation.suspicious.length ? (
          <div className="data-quality-banner" role="alert">
            <strong>DATA ERROR — sprawdź źródło przed decyzją treningową.</strong>
            {validation.missing.length ? <span>Brak: {validation.missing.join(', ')}</span> : null}
            {validation.suspicious.length ? <span>{validation.suspicious.join(' · ')}</span> : null}
          </div>
        ) : null}

        {loading && !feed.length ? <SkeletonRings /> : feed.length ? (
          <div className="rings-grid">
            <MetricRing label="RECOVERY" value={values.recovery} max={100} note="Gotowość do pracy" issue={issueFor('recovery')} />
            <MetricRing label="STRAIN" value={values.strain} max={21} suffix="" note="Obciążenie dnia · skala 0–21" />
            <MetricRing label="SLEEP" value={values.sleep} max={100} note="Jakość / realizacja snu" issue={issueFor('sleep')} />
          </div>
        ) : <EmptyState title="Brak danych APP_FEED">Odśwież aplikację albo sprawdź arkusz źródłowy.</EmptyState>}
      </section>

      <section className="section-block">
        <div className="section-heading"><div><span className="eyebrow">BAZA</span><h2>Kluczowe parametry</h2></div></div>
        <div className="stats-grid">
          <StatCard label="HRV" value={values.hrv} unit="ms" note="zmienność rytmu serca" />
          <StatCard label="RHR" value={values.rhr} unit="bpm" note="tętno spoczynkowe" />
          <StatCard label="WAGA" value={values.weight} unit="kg" note="ostatni odczyt" />
          <StatCard label="KROKI" value={values.steps} note="aktywność dzienna" />
          {values.srpe ? <StatCard label="sRPE" value={values.srpe} note="realne obciążenie sesji" /> : null}
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div><span className="eyebrow">NASTĘPNE</span><h2>Najbliższe sesje</h2></div>
          <span className="section-aside">{upcoming.length} w planie</span>
        </div>
        {loading && !plan.length ? <SkeletonRings /> : upcoming.length ? (
          <div className="plan-list compact">
            {upcoming.map((row, index) => (
              <PlanRow row={row} key={`${getValue(row, 'date', '')}-${index}`} />
            ))}
          </div>
        ) : <EmptyState title="Brak przyszłych sesji">Wpisy bez daty nie są przedstawiane jako „najbliższe”.</EmptyState>}
      </section>
    </>
  );
}

function Zones({ feed, log, loading }) {
  const latestFeed = latestRow(feed);
  const latestLog = latestRow(log);
  const zoneValues = ZONE_META.map((zone) => getFeedValue(feed, latestFeed, `z${zone.id}`, getValue(latestLog, `z${zone.id}`, '')));
  const amounts = zoneValues.map((v) => parseMetric(v));
  const total = amounts.reduce((sum, n) => sum + (n ?? 0), 0);

  return (
    <>
      <Hero eyebrow="INTENSYWNOŚĆ" title="Strefy wysiłku" orbit={false}>
        Odczyt z APP_FEED z fallbackiem do ostatniego treningu.
      </Hero>
      <section className="section-block zone-list">
        {loading && !feed.length && !log.length ? <SkeletonRings /> : ZONE_META.map((zone, index) => {
          const raw = zoneValues[index];
          const amount = amounts[index];
          const width = amount !== null && total > 0 && amount > 0 ? Math.max(2, (amount / total) * 100) : 0;
          return (
            <article className="zone-card" key={zone.id}>
              <div className="zone-badge" style={{ background: zone.color }}>Z{zone.id}</div>
              <div className="zone-main">
                <strong>{zone.name}</strong>
                <small>{zone.note}</small>
                <div className="zone-track"><span style={{ width: `${width}%`, background: zone.color }} /></div>
              </div>
              <b>{raw || '—'}</b>
            </article>
          );
        })}
      </section>
      <section className="source-card">
        <span className="eyebrow">ŹRÓDŁO</span>
        <p>Mapowanie pól jest jawne i używa wyłącznie exact match. Brak zgodnej kolumny nie może zostać pomylony z inną metryką.</p>
      </section>
    </>
  );
}

function Log({ rows, loading }) {
  const sorted = useMemo(() => sortByDate(rows, 'desc'), [rows]);
  const columns = [
    { label: 'Data', field: 'date', format: (v) => formatDate(v) },
    { label: 'Trening', field: 'session' },
    { label: 'Czas', field: 'duration' },
    { label: 'sRPE', field: 'srpe' },
    { label: 'Kalorie', field: 'calories' },
  ];

  return (
    <>
      <Hero eyebrow="HISTORIA" title="Training Log" orbit={false}>
        Ostatnie sesje, posortowane od najnowszej poprawnej daty.
      </Hero>
      <section className="section-block">
        {loading && !rows.length ? <SkeletonRings /> : rows.length ? (
          <div className="table-shell">
            <table>
              <thead><tr>{columns.map((c) => <th key={c.field}>{c.label}</th>)}</tr></thead>
              <tbody>
                {sorted.map((row, index) => (
                  <tr key={`${getValue(row, 'date', '')}-${index}`}>
                    {columns.map((column) => {
                      const raw = getValue(row, column.field, '');
                      return <td key={column.field}>{raw ? (column.format ? column.format(raw) : raw) : '—'}</td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <EmptyState title="Brak wpisów">Training Log nie zwrócił żadnych rekordów.</EmptyState>}
      </section>
    </>
  );
}

function PlanRow({ row }) {
  const date = getValue(row, 'date', '');
  const session = getValue(row, 'session', 'Sesja');
  const target = getValue(row, 'target', '');
  const notes = getValue(row, 'notes', '');
  return (
    <article className="plan-item">
      <div className="plan-date">{date ? formatDate(date) : '—'}</div>
      <div className="plan-copy">
        <span>{target || '—'}</span>
        <strong>{session}</strong>
        <p>{notes || 'Brak dodatkowych uwag'}</p>
      </div>
    </article>
  );
}

function Plan({ rows, loading }) {
  const dated = useMemo(() => sortByDate(rows.filter((row) => rowDate(row)), 'asc'), [rows]);
  const undated = useMemo(() => rows.filter((row) => !rowDate(row)), [rows]);
  return (
    <>
      <Hero eyebrow="DROGA DO CELU" title="Plan" orbit={false}>
        Najbliższe jednostki i priorytety prowadzące do Málaga 2027.
      </Hero>
      <section className="section-block">
        {loading && !rows.length ? <SkeletonRings /> : dated.length ? (
          <div className="plan-list">{dated.map((row, i) => <PlanRow row={row} key={`${getValue(row, 'date', '')}-${i}`} />)}</div>
        ) : <EmptyState title="Brak zaplanowanych dat">Plan nie zawiera obecnie terminowych sesji.</EmptyState>}
      </section>
      {undated.length ? (
        <section className="section-block">
          <div className="section-heading"><div><span className="eyebrow">PLAN</span><h2>Bez terminu</h2></div></div>
          <div className="plan-list">{undated.map((row, i) => <PlanRow row={row} key={`undated-${i}`} />)}</div>
        </section>
      ) : null}
    </>
  );
}

function App() {
  const [tab, setTab] = useState('dashboard');
  const [data, setData] = useState({ feed: [], log: [], plan: [] });
  const [loading, setLoading] = useState(true);
  const [syncedAt, setSyncedAt] = useState(null);
  const [checkedAt, setCheckedAt] = useState(null);
  const [errors, setErrors] = useState({});
  const [fromCache, setFromCache] = useState(false);

  const dataRef = useRef(data);
  const inFlight = useRef(null);
  const lastAttempt = useRef(0);

  useEffect(() => { dataRef.current = data; }, [data]);

  const refresh = useCallback(async ({ force = false } = {}) => {
    if (!force && Date.now() - lastAttempt.current < MIN_REFRESH_MS) return;
    lastAttempt.current = Date.now();

    if (inFlight.current) inFlight.current.abort();
    const controller = new AbortController();
    inFlight.current = controller;
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT);

    setLoading(true);
    const entries = Object.entries(SHEETS);
    const results = await Promise.allSettled(entries.map(([, sheetName]) => fetchSheet(sheetName, controller.signal)));
    clearTimeout(timer);

    if (inFlight.current !== controller) return;
    inFlight.current = null;

    const nextErrors = {};
    const merged = { ...dataRef.current };
    let anyOk = false;

    results.forEach((result, index) => {
      const [key, sheetName] = entries[index];
      if (result.status === 'fulfilled') {
        merged[key] = result.value;
        anyOk = true;
      } else {
        nextErrors[key] = result.reason?.name === 'AbortError'
          ? `${sheetName}: przekroczono czas (${FETCH_TIMEOUT / 1000}s)`
          : result.reason?.message || `${sheetName}: błąd pobierania`;
      }
    });

    setData(merged);
    setErrors(nextErrors);
    setCheckedAt(Date.now());

    if (anyOk) {
      const at = Date.now();
      setSyncedAt(at);
      setFromCache(false);
      try {
        localStorage.setItem(SNAPSHOT_KEY, JSON.stringify({ data: merged, at }));
      } catch {
        // Safari private mode / quota: snapshot is optional.
      }
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(SNAPSHOT_KEY);
      const snap = raw ? JSON.parse(raw) : null;
      if (snap?.data) {
        setData(snap.data);
        dataRef.current = snap.data;
        setSyncedAt(snap.at);
        setFromCache(true);
      }
    } catch {
      // Corrupted snapshot: ignore and continue with network.
    }
    refresh({ force: true });
  }, [refresh]);

  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') refresh(); };
    const onPageShow = (event) => { if (event.persisted) refresh(); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('pageshow', onPageShow);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('pageshow', onPageShow);
    };
  }, [refresh]);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return undefined;
    const register = () => navigator.serviceWorker.register('./sw.js').catch(() => undefined);
    window.addEventListener('load', register);
    return () => window.removeEventListener('load', register);
  }, []);

  const errorCount = Object.keys(errors).length;
  const isStale = syncedAt !== null && Date.now() - syncedAt > STALE_AFTER_MS;
  const offline = errorCount === Object.keys(SHEETS).length;
  const status = offline ? 'offline' : isStale ? 'stale' : errorCount ? 'partial' : 'live';
  const statusLabel = {
    live: 'Dane aktualne',
    partial: 'Dane częściowe',
    stale: 'Dane nieaktualne',
    offline: 'Offline — dane zapisane lokalnie',
  }[status];

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setTab('dashboard')} aria-label="Przejdź do Dashboard">
          <span className="brand-mark">C</span>
          <span><strong>CARLOS</strong><small>MÁLAGA 2027</small></span>
        </button>
        <nav className="desktop-nav" aria-label="Główna nawigacja">
          {TABS.map((item) => (
            <button key={item.id} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}>{item.label}</button>
          ))}
        </nav>
        <button className="refresh-button" onClick={() => refresh({ force: true })} disabled={loading} aria-label="Odśwież dane">
          <span className={loading ? 'spin' : ''}>↻</span><b>{loading ? 'Sync' : 'Odśwież'}</b>
        </button>
      </header>

      <div className={`sync-strip status-${status}`} aria-live="polite">
        <span className="live-dot" />
        <span className="sync-main">{statusLabel}</span>
        <span className="sync-times">Dane z: {syncedAt ? formatUpdated(new Date(syncedAt)) : '—'} · Sprawdzono: {checkedAt ? formatUpdated(new Date(checkedAt)) : '—'}</span>
      </div>

      {errorCount ? (
        <div className="error-banner" role="status">
          <strong>{offline ? 'Brak połączenia ze źródłem danych.' : 'Nie wszystkie arkusze odświeżone.'}</strong>
          <span>{Object.values(errors).join(' · ')}</span>
          {fromCache ? <span>Pokazane dane pochodzą z lokalnej kopii.</span> : null}
        </div>
      ) : null}

      <main>
        {tab === 'dashboard' && <Dashboard feed={data.feed} plan={data.plan} loading={loading} />}
        {tab === 'zones' && <Zones feed={data.feed} log={data.log} loading={loading} />}
        {tab === 'log' && <Log rows={data.log} loading={loading} />}
        {tab === 'plan' && <Plan rows={data.plan} loading={loading} />}
      </main>

      <nav className="mobile-nav" aria-label="Dolna nawigacja">
        {TABS.map((item) => (
          <button key={item.id} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}>
            <span aria-hidden="true">{item.icon}</span><small>{item.label}</small>
          </button>
        ))}
      </nav>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);

```

## `src/styles.css`

```css
:root {
  color-scheme: dark;
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", system-ui, sans-serif;
  background: #07090d;
  color: #f6f7fb;
  --bg: #07090d;
  --panel: #12161e;
  --panel-2: #151a23;
  --line: rgba(255,255,255,.10);
  --muted: #8f98aa;
  --muted-2: #b5bdc9;
  --orange: #ff7b2a;
  --green: #77f2b5;
  --yellow: #ffd34e;
  --red: #ff526d;
  --safe-top: env(safe-area-inset-top, 0px);
  --safe-bottom: env(safe-area-inset-bottom, 0px);
}

* { box-sizing: border-box; }
html { background: var(--bg); }
body {
  margin: 0;
  min-width: 320px;
  min-height: 100dvh;
  background:
    radial-gradient(circle at 12% -3%, rgba(255,123,42,.09), transparent 28rem),
    var(--bg);
  color: #f8f9fc;
  overscroll-behavior-y: contain;
}
button, input, select, textarea { font: inherit; }
button { color: inherit; }
button:focus-visible { outline: 2px solid var(--yellow); outline-offset: 3px; }

.app-shell { min-height: 100dvh; padding-bottom: calc(96px + var(--safe-bottom)); }
.topbar {
  position: sticky;
  top: 0;
  z-index: 30;
  min-height: calc(82px + var(--safe-top));
  padding: var(--safe-top) clamp(22px, 4vw, 54px) 0;
  display: grid;
  grid-template-columns: auto 1fr auto;
  align-items: center;
  gap: 24px;
  background: rgba(7,9,13,.88);
  border-bottom: 1px solid rgba(255,255,255,.035);
  -webkit-backdrop-filter: blur(18px) saturate(120%);
  backdrop-filter: blur(18px) saturate(120%);
}
.brand {
  min-height: 48px;
  display: inline-flex;
  align-items: center;
  gap: 12px;
  background: none;
  border: 0;
  padding: 0;
  cursor: pointer;
  text-align: left;
}
.brand-mark {
  width: 48px;
  height: 48px;
  display: grid;
  place-items: center;
  border-radius: 16px;
  background: linear-gradient(145deg, rgba(255,211,78,.18), rgba(255,82,109,.12));
  border: 1px solid rgba(255,255,255,.12);
  color: #ffd34e;
  font-size: 1.2rem;
  font-weight: 900;
}
.brand > span:last-child { display: grid; gap: 2px; }
.brand strong { font-size: 1rem; letter-spacing: .18em; }
.brand small { color: var(--muted); font-size: .7rem; letter-spacing: .24em; }
.desktop-nav { justify-self: center; display: flex; gap: 6px; }
.desktop-nav button {
  min-height: 44px;
  padding: 0 16px;
  border: 0;
  border-radius: 14px;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  font-weight: 700;
}
.desktop-nav button.active { color: #fff; background: rgba(255,255,255,.07); }
.refresh-button {
  min-width: 44px;
  min-height: 44px;
  padding: 0 14px;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  border-radius: 999px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.035);
  cursor: pointer;
}
.refresh-button:disabled { opacity: .58; cursor: wait; }
.refresh-button span { font-size: 1.4rem; line-height: 1; }
.refresh-button b { font-size: .76rem; }
.spin { display: inline-block; animation: spin .8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.sync-strip {
  min-height: 38px;
  padding: 8px clamp(22px, 4vw, 54px);
  display: flex;
  align-items: center;
  gap: 9px;
  flex-wrap: wrap;
  border-bottom: 1px solid rgba(255,255,255,.035);
  background: rgba(17,19,25,.78);
  font-size: .75rem;
}
.live-dot { width: 8px; height: 8px; flex: 0 0 auto; border-radius: 50%; }
.sync-main { font-weight: 700; color: var(--muted-2); }
.sync-times { margin-left: auto; color: var(--muted); font-variant-numeric: tabular-nums; }
.status-live .live-dot { background: var(--green); box-shadow: 0 0 14px rgba(119,242,181,.7); }
.status-partial .live-dot,
.status-stale .live-dot { background: var(--yellow); box-shadow: 0 0 14px rgba(255,211,78,.55); }
.status-offline .live-dot { background: var(--red); box-shadow: 0 0 14px rgba(255,82,109,.55); }
.status-stale .sync-main { color: var(--yellow); }
.status-offline .sync-main { color: var(--red); }
.error-banner,
.data-quality-banner {
  margin: 14px auto 0;
  width: min(1120px, calc(100% - 44px));
  display: grid;
  gap: 6px;
  padding: 13px 16px;
  border-radius: 16px;
  font-size: .78rem;
}
.error-banner { background: rgba(255,211,78,.08); border: 1px solid rgba(255,211,78,.25); color: #f4df99; }
.data-quality-banner { background: rgba(255,82,109,.08); border: 1px solid rgba(255,82,109,.28); color: #ffc0cb; margin: 0 0 18px; width: 100%; }
.error-banner span, .data-quality-banner span { color: var(--muted-2); }

main {
  width: min(1180px, 100%);
  min-height: calc(100dvh - 180px);
  margin: 0 auto;
  padding: 24px clamp(22px, 4vw, 54px) 60px;
}
.hero-panel {
  position: relative;
  min-height: 320px;
  overflow: hidden;
  display: grid;
  grid-template-columns: minmax(0, 1fr) 280px;
  align-items: center;
  margin-bottom: 52px;
  padding: 48px;
  border: 1px solid rgba(255,255,255,.11);
  border-radius: 34px;
  background:
    linear-gradient(135deg, rgba(255,123,42,.09), transparent 48%),
    #171312;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.03);
}
.hero-copy { position: relative; z-index: 2; max-width: 760px; }
.eyebrow {
  display: block;
  margin-bottom: 14px;
  color: #aab2c2;
  font-size: .72rem;
  font-weight: 800;
  letter-spacing: .28em;
  text-transform: uppercase;
}
.hero-copy h1,
.zone-hero h1,
.section-hero h1 {
  margin: 0;
  max-width: 820px;
  font-size: clamp(3rem, 6.8vw, 6.8rem);
  line-height: .92;
  letter-spacing: -.06em;
}
.hero-copy p {
  max-width: 720px;
  margin: 24px 0 0;
  color: #a9b0bf;
  font-size: clamp(1rem, 2vw, 1.35rem);
  line-height: 1.5;
}
.hero-orbit {
  position: absolute;
  width: 310px;
  height: 310px;
  right: -44px;
  bottom: -88px;
  border-radius: 50%;
  background:
    radial-gradient(circle at center, #07090d 0 30%, transparent 31%),
    conic-gradient(from 22deg, #f07822 0 19%, #1b1818 19% 45%, #64d8a2 45% 59%, #58c5e8 59% 73%, #18181b 73% 100%);
  border: 18px solid rgba(0,0,0,.22);
  opacity: .86;
}
.hero-orbit b {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 2.3rem;
  color: #d8d9de;
}

.section-block { margin: 0 0 52px; }
.section-heading { display: flex; align-items: end; justify-content: space-between; gap: 24px; margin-bottom: 22px; }
.section-heading .eyebrow { margin: 0 0 9px; }
.section-heading h2 { margin: 0; font-size: clamp(1.8rem, 4.2vw, 3.1rem); letter-spacing: -.04em; }
.section-aside { color: var(--muted); font-size: .76rem; font-weight: 800; letter-spacing: .16em; text-transform: uppercase; }

.rings-grid { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 18px; }
.ring-card,
.stat-card,
.zone-card,
.plan-item,
.table-shell,
.empty-state,
.source-card {
  background: var(--panel);
  border: 1px solid rgba(255,255,255,.105);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.02);
}
.ring-card {
  min-height: 260px;
  border-radius: 28px;
  padding: 28px;
  display: grid;
  grid-template-columns: minmax(135px, 180px) 1fr;
  align-items: center;
  gap: 24px;
}
.metric-ring {
  position: relative;
  width: min(100%, 170px);
  aspect-ratio: 1;
  border-radius: 50%;
  display: grid;
  place-items: center;
}
.metric-ring::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: conic-gradient(#f2f4f7 var(--progress), #1b1f28 0);
  -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 12px), #000 calc(100% - 11px));
  mask: radial-gradient(farthest-side, transparent calc(100% - 12px), #000 calc(100% - 11px));
}
.metric-ring-inner { text-align: center; display: grid; gap: 8px; position: relative; z-index: 1; }
.metric-ring strong { font-size: clamp(1.7rem, 3.2vw, 2.6rem); letter-spacing: -.04em; }
.metric-ring span { color: #aab2c2; font-size: .68rem; font-weight: 800; letter-spacing: .19em; }
.ring-card p { margin: 0; color: var(--muted); font-size: .9rem; line-height: 1.5; }
.ring-empty .metric-ring::before,
.ring-error .metric-ring::before {
  background: none;
  border: 3px dashed rgba(255,255,255,.14);
  -webkit-mask: none;
  mask: none;
}
.ring-error .metric-ring::before { border-color: rgba(255,82,109,.5); }
.ring-empty .metric-ring strong { color: var(--muted); }
.ring-error .metric-ring strong { color: var(--red); }
.ring-note-issue { color: #c6ad96 !important; font-weight: 700; }

.stats-grid { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 16px; }
.stat-card { min-height: 200px; padding: 26px; border-radius: 26px; display: flex; flex-direction: column; }
.stat-card > span { color: #aab2c2; font-size: .73rem; font-weight: 800; letter-spacing: .16em; }
.stat-card > strong { margin: auto 0 12px; font-size: clamp(2rem, 4vw, 3.2rem); font-variant-numeric: tabular-nums; }
.stat-card > strong small { color: #dce0e8; font-size: .9rem; }
.stat-card > small { color: var(--muted); font-size: .78rem; }

.plan-list { display: grid; gap: 14px; }
.plan-list.compact { grid-template-columns: repeat(3, minmax(0,1fr)); }
.plan-item { min-height: 138px; padding: 22px; border-radius: 25px; display: grid; grid-template-columns: 84px 1fr; gap: 20px; align-items: center; }
.plan-date { min-height: 84px; border: 1px solid rgba(255,255,255,.11); border-radius: 20px; display: grid; place-items: center; padding: 10px; color: #f2f4f7; font-size: 1.15rem; font-weight: 800; text-transform: uppercase; text-align: center; }
.plan-copy { min-width: 0; }
.plan-copy > span { display: block; margin-bottom: 8px; color: var(--orange); font-size: .68rem; font-weight: 800; letter-spacing: .14em; text-transform: uppercase; }
.plan-copy strong { display: block; font-size: 1.12rem; }
.plan-copy p { margin: 7px 0 0; color: var(--muted); font-size: .8rem; line-height: 1.45; }

.zone-list { display: grid; gap: 15px; }
.zone-card { min-height: 138px; padding: 20px 24px; border-radius: 26px; display: grid; grid-template-columns: 82px 1fr auto; align-items: center; gap: 20px; }
.zone-badge { width: 72px; height: 72px; border-radius: 22px; display: grid; place-items: center; color: #071017; font-weight: 900; }
.zone-main { min-width: 0; display: grid; gap: 4px; }
.zone-main strong { font-size: 1.2rem; }
.zone-main small { color: var(--muted); }
.zone-card > b { font-size: 1.3rem; font-variant-numeric: tabular-nums; }
.zone-track { height: 7px; margin-top: 14px; overflow: hidden; border-radius: 999px; background: rgba(255,255,255,.055); }
.zone-track span { display: block; min-width: 0; height: 100%; border-radius: inherit; }
.source-card { margin-bottom: 56px; padding: 28px; border-radius: 26px; }
.source-card .eyebrow { margin-bottom: 12px; }
.source-card p { margin: 0; color: var(--muted); line-height: 1.6; }

.table-shell { overflow-x: auto; border-radius: 26px; }
table { width: 100%; border-collapse: collapse; min-width: 680px; }
th, td { padding: 20px 24px; text-align: left; border-bottom: 1px solid rgba(255,255,255,.085); }
th { color: #aab2c2; font-size: .69rem; letter-spacing: .16em; text-transform: uppercase; }
td { color: #d8dce5; font-size: .9rem; font-variant-numeric: tabular-nums; }
tbody tr:last-child td { border-bottom: 0; }

.empty-state { min-height: 170px; padding: 28px; border-radius: 26px; display: flex; align-items: center; gap: 22px; }
.empty-mark { width: 72px; height: 72px; flex: 0 0 auto; border-radius: 50%; display: grid; place-items: center; border: 2px dashed rgba(255,255,255,.16); color: var(--muted); font-size: 1.8rem; }
.empty-state strong { display: block; margin-bottom: 7px; }
.empty-state p { margin: 0; color: var(--muted); line-height: 1.5; }

.skeleton-rings { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.skeleton-rings i {
  min-height: 250px;
  border-radius: 24px;
  background: linear-gradient(100deg, rgba(255,255,255,.03) 30%, rgba(255,255,255,.07) 50%, rgba(255,255,255,.03) 70%);
  background-size: 220% 100%;
  animation: shimmer 1.4s linear infinite;
}
@keyframes shimmer { to { background-position: -220% 0; } }

.mobile-nav { display: none; }

@media (max-width: 980px) {
  .rings-grid { grid-template-columns: 1fr; }
  .stats-grid { grid-template-columns: repeat(2, minmax(0,1fr)); }
  .plan-list.compact { grid-template-columns: 1fr; }
}

@media (max-width: 880px) {
  .desktop-nav { display: none; }
  .mobile-nav {
    position: fixed;
    z-index: 50;
    left: 18px;
    right: 18px;
    bottom: max(12px, var(--safe-bottom));
    min-height: 74px;
    padding: 8px;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 28px;
    background: rgba(18,22,30,.91);
    -webkit-backdrop-filter: blur(20px) saturate(130%);
    backdrop-filter: blur(20px) saturate(130%);
    box-shadow: 0 18px 50px rgba(0,0,0,.35);
  }
  .mobile-nav button {
    min-width: 44px;
    min-height: 54px;
    display: grid;
    place-items: center;
    align-content: center;
    gap: 4px;
    border: 0;
    border-radius: 20px;
    background: transparent;
    color: var(--muted);
  }
  .mobile-nav button.active { color: #fff; background: rgba(255,255,255,.07); }
  .mobile-nav button span { font-size: 1.25rem; line-height: 1; }
  .mobile-nav button small { font-size: .69rem; font-weight: 700; }
  .app-shell { padding-bottom: calc(108px + var(--safe-bottom)); }
}

@media (max-width: 640px) {
  .topbar {
    min-height: calc(72px + var(--safe-top));
    padding-left: 20px;
    padding-right: 20px;
    gap: 12px;
  }
  .brand-mark { width: 42px; height: 42px; border-radius: 14px; }
  .brand strong { font-size: .92rem; }
  .brand small { font-size: .62rem; }
  .refresh-button { min-width: 44px; min-height: 44px; padding: 0 12px; }
  .refresh-button b { display: none; }
  .sync-strip { padding-left: 20px; padding-right: 20px; font-size: .69rem; }
  .sync-times { width: 100%; margin-left: 17px; }
  main { padding: 18px 20px 50px; }
  .hero-panel {
    min-height: 0;
    grid-template-columns: 1fr;
    align-items: start;
    margin-bottom: 34px;
    padding: 18px 20px;
    border-radius: 24px;
  }
  .hero-copy h1,
  .zone-hero h1,
  .section-hero h1 { font-size: clamp(1.5rem, 7vw, 2.1rem); line-height: 1.02; letter-spacing: -.045em; }
  .hero-panel .hero-copy p { display: none; }
  .hero-orbit { width: 96px; height: 96px; right: -20px; bottom: -16px; opacity: .5; border-width: 8px; }
  .hero-orbit b { font-size: 1.1rem; }
  .eyebrow { margin-bottom: 8px; font-size: .62rem; }
  .section-block { margin-bottom: 38px; }
  .section-heading { margin-bottom: 16px; }
  .section-heading h2 { font-size: 1.65rem; }
  .section-aside { font-size: .63rem; }
  .rings-grid, .skeleton-rings { grid-template-columns: 1fr; }
  .ring-card { min-height: 176px; grid-template-columns: 118px 1fr; padding: 20px; border-radius: 24px; }
  .metric-ring { width: 118px; }
  .metric-ring strong { font-size: 1.6rem; }
  .stats-grid { grid-template-columns: repeat(2, minmax(0,1fr)); gap: 12px; }
  .stat-card { min-height: 150px; padding: 20px; border-radius: 22px; }
  .stat-card > strong { font-size: 2rem; }
  .zone-card { min-height: 116px; padding: 18px; grid-template-columns: 64px 1fr auto; gap: 14px; border-radius: 22px; }
  .zone-badge { width: 58px; height: 58px; border-radius: 18px; }
  .zone-card > b { font-size: 1rem; }
  .plan-item { grid-template-columns: 70px 1fr; min-height: 118px; padding: 18px; border-radius: 22px; gap: 14px; }
  .plan-date { min-height: 70px; border-radius: 17px; font-size: .93rem; }
  .error-banner, .data-quality-banner { width: 100%; margin-left: 0; margin-right: 0; }
  .error-banner { margin-top: 10px; border-radius: 0; }
  .skeleton-rings i { min-height: 176px; }
  .source-card { padding: 22px; border-radius: 22px; }
  .mobile-nav { left: 14px; right: 14px; }
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { scroll-behavior: auto !important; animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; }
}

```

## `public/manifest.webmanifest`

```json
{
  "name": "CARLOS — MÁLAGA 2027",
  "short_name": "CARLOS",
  "description": "Trening, strefy, log i plan — CARLOS MÁLAGA 2027.",
  "start_url": "./",
  "scope": "./",
  "display": "standalone",
  "orientation": "portrait-primary",
  "background_color": "#07090d",
  "theme_color": "#07090d",
  "icons": [
    { "src": "./icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "./icon-512.png", "sizes": "512x512", "type": "image/png" },
    { "src": "./icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}

```

## `public/icon.svg`

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" role="img" aria-label="CARLOS">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#392d23"/>
      <stop offset="1" stop-color="#17151a"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="128" fill="#07090d"/>
  <rect x="42" y="42" width="428" height="428" rx="112" fill="url(#bg)" stroke="#51483f" stroke-width="10"/>
  <circle cx="256" cy="256" r="148" fill="none" stroke="#ff7b2a" stroke-width="24" stroke-dasharray="220 710" transform="rotate(-38 256 256)"/>
  <circle cx="256" cy="256" r="148" fill="none" stroke="#64d8a2" stroke-width="24" stroke-dasharray="135 795" transform="rotate(104 256 256)"/>
  <circle cx="256" cy="256" r="148" fill="none" stroke="#58c5e8" stroke-width="24" stroke-dasharray="110 820" transform="rotate(156 256 256)"/>
  <text x="256" y="326" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="210" font-weight="900" fill="#ffd34e">C</text>
</svg>

```

## `public/sw.js`

```javascript
const CACHE_NAME = 'carlos-malaga-2027-v2';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon.svg',
  './icon-180.png',
  './icon-192.png',
  './icon-512.png',
];
const NAV_TIMEOUT = 3000;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => Promise.allSettled(APP_SHELL.map((url) => cache.add(url))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

function timedFetch(request, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('timeout')), ms);
    fetch(request).then(
      (response) => { clearTimeout(timer); resolve(response); },
      (error) => { clearTimeout(timer); reject(error); },
    );
  });
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  if (url.hostname === 'docs.google.com' || url.hostname.endsWith('.googleusercontent.com')) {
    event.respondWith(fetch(request));
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(
      timedFetch(request, NAV_TIMEOUT)
        .then((response) => {
          if (response.ok && response.type === 'basic') {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put('./', copy));
          }
          return response;
        })
        .catch(() => caches.match('./').then((cached) => cached || caches.match('./index.html'))),
    );
    return;
  }

  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then((cached) => cached || fetch(request).then((response) => {
        if (response.ok && response.type === 'basic') {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        }
        return response;
      })),
    );
  }
});

```

## `README.md`

```markdown
# CARLOS — MÁLAGA 2027

PWA React/Vite do monitorowania treningu i regeneracji zasilana Google Sheets.

## Dane

- `APP_FEED`
- `Training Log`
- `Plan`
- Google Sheet ID: `1FoExswYMSy5Ou2HwyzPd3bWgnplWgfPGCd5scC0lCXM`

Aplikacja pobiera CSV przez Google `gviz`, używa `cache: no-store`, parametru cache-busting, timeoutu `AbortController`, last-known-good w `localStorage` i jawnego mapowania pól exact-match.

## Uruchomienie

```bash
npm install
npm run dev
```

## Testy

```bash
npm test
npm run build
```

## Ważne

Ta wersja realizuje pakiet poprawek integralności danych, offline, iOS safe-area, touch targets, WCAG i service workera. Migracja z publicznego CSV do prywatnego Google Sheet przez uwierzytelnione Vercel API jest kolejnym etapem i nie jest częścią tego patcha.

```
